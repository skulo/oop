CREATE TABLE Highscores (
    name VARCHAR(255),
    score INT,
    seconds INT
);